﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class GuessTheNumber : MonoBehaviour {

	// Use this for initialization
	void Start () {
		print("hello world");
	}
	
	// Update is called once per frame
	void Update () {
		 
	}
}
